

// Function to replace words with "[REDACTED]"
function redactText(redactedWords) {
  // Get all text nodes on the page
  const textNodes = document.createTreeWalker(
    document.body,
    NodeFilter.SHOW_TEXT,
    null,
    false
  );

  // Iterate over each text node
  while (textNodes.nextNode()) {
    const node = textNodes.currentNode;
    // Replace each redacted word found in the text node
    redactedWords.forEach(redactedWord => {
      function escapeRegExp(string) {
          return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      }
      const regex = new RegExp(`\\b${escapeRegExp(redactedWord)}\\b`, 'gi');
      node.nodeValue = node.nodeValue.replace(regex, '[REDACTED]');
    });
  }
}

redactText((`Abinarys
Agenders
Ambigenders
Androgynes
Androgynous
Aporagenders
Autigenders
Baklas
Bigenders
Binarys
Bissus
Butchs
Calabais
Calalais
Cis
Cisgenders
Demi-boys
Demifluxs
Demigenders
Demi-girls
Demi-guys
Demi-mans
Demi-womans
Dual genders
Eunuchs
Gender benders
Gender diverses
Gender gifteds
Genderfaes
Genderfluids
Genderfluxs
Genderfucks
Genderless
Gender nonconformings
Genderqueers
Gender questionings
Gender variants
Graygenders
Hijras
Homosexuals
Intergenders
Intersexs
Ipsogenders
Kathoeys
Māhūs
Male to females
Men of trans experience
Maveriques
Meta-genders
MTFs
Multigenders
Muxes
Neithers
Neurogenders
Neutroiss
non-binarys
Non-binary transgenders
Queers
Sekhets
Third genders
Trans
Trans
Trans females
Trans males
Trans mans
Trans persons
Trans womans
Transgenders
Transgender females
Transgender males
Transgender men
Transgender people
Transgender women
Transfeminines
Transmasculines
Transsexuals
Transsexual females
Transsexual males
Transsexual men
Transsexual people
Transsexual women
Travestis
Trigenders
Tumtums
Two spirits
Vakasalewalewas
X-genders
X-jendās
Xenogenders
Abinary
Agender
Ambigender
Androgyne
Androgynous
Aporagender
Autigender
Bakla
Bigender
Binary
Bissu
Butch
Calabai
Calalai
Cis
Cisgender
Demi-boy
Demiflux
Demigender
Demi-girl
Demi-guy
Demi-man
Demi-woman
Dual gender
Eunuch
Gender bender
Gender diverse
Gender gifted
Genderfae
Genderfluid
Genderflux
Genderfuck
Genderless
Gender nonconforming
Genderqueer
Gender questioning
Gender variant
Graygender
Hijra
Homosexual
Intergender
Intersex
Ipsogender
Kathoey
LGBT
LGBTQ
Māhū
Male[4]
Male to female
Man
Man of trans experience
Maverique
Meta-gender
MTF
Multigender
Muxe
Neither
Neurogender
Neutrois
non-binary
Non-binary transgender
Queer
Sekhet
Third gender
Trans
Trans
Trans female
Trans male
Trans man
Trans person
Trans woman
Transgender
Transgender female
Transgender male
Transgender man
Transgender person
Transgender woman
Transfeminine
Transmasculine
Transsexual
Transsexual female
Transsexual male
Transsexual man
Transsexual person
Transsexual woman
Travesti
Trigender
Tumtum
Two spirit
Vakasalewalewa
X-gender
X-jendā
Xenogender
Lesbian
Bisexual
Gay
Same-sex relationship
They/Them
Ze/Zem`).split('\n').map(word => word.trim()));
