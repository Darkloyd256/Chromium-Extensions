console.log("Blocker Activated.");
